export default function FlashCardPage() {
  return (
    <div>
      <h1>Flashcards</h1>
      <p>This is the flashcard page.</p>
    </div>
  );
}
