'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import ProtectedRoute from '@/components/ProtectedRoute';
import { Modal } from '@/components/ui/Modal';
import { fetchSummaries } from '@/services/api';
import { FiUpload, FiFileText } from 'react-icons/fi';
import FileUploadModal from './components/FileUploadModal';
import TextInputModal from './components/TextInputModal';
import axios from 'axios';

export default function Summaries() {
  const router = useRouter();
  const [summaries, setSummaries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isMethodModalOpen, setIsMethodModalOpen] = useState(false);
  const [isFileModalOpen, setIsFileModalOpen] = useState(false);
  const [isTextModalOpen, setIsTextModalOpen] = useState(false);
  const [selectedSummary, setSelectedSummary] = useState(null);
  const [showSummaryModal, setShowSummaryModal] = useState(false);
  const [sortField, setSortField] = useState('createdAt');
  const [sortDirection, setSortDirection] = useState('desc');

  useEffect(() => {
    loadSummaries();
  }, []);

  const loadSummaries = async () => {
    setLoading(true);
    try {
      const response = await fetchSummaries();
      if (response.success) {
        setSummaries(response.summaries);
      }
    } catch (error) {
      console.error('Error loading summaries:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSort = (field) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const sortedSummaries = [...summaries].sort((a, b) => {
    if (sortField === 'createdAt') {
      return sortDirection === 'asc' 
        ? new Date(a.createdAt) - new Date(b.createdAt)
        : new Date(b.createdAt) - new Date(a.createdAt);
    }
    const valueA = a[sortField]?.toLowerCase() || '';
    const valueB = b[sortField]?.toLowerCase() || '';
    return sortDirection === 'asc' 
      ? valueA.localeCompare(valueB)
      : valueB.localeCompare(valueA);
  });

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const viewSummary = (summary) => {
    setSelectedSummary(summary);
    setShowSummaryModal(true);
  };

  const handleDelete = async (summaryId) => {
    if (!window.confirm("Are you sure you want to delete this summary?")) return;

    try {
      await axios.delete(`http://localhost:5600/api/summary/${summaryId}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });

      alert("Summary deleted successfully!");
      loadSummaries();  // Refresh the list after deletion
    } catch (error) {
      console.error("Error deleting summary:", error);
      alert("Failed to delete summary.");
    }
  };

  return (
    <ProtectedRoute>
      <div className="space-y-6">
        {/* Create Summary Card */}
        <div 
          onClick={() => setIsMethodModalOpen(true)}
          className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm cursor-pointer hover:shadow-md transition-shadow border-2 border-dashed border-gray-300 dark:border-gray-600"
        >
          <div className="flex items-center justify-center h-32">
            <div className="text-center">
              <span className="text-4xl mb-2">➕</span>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mt-2">
                Create New Summary
              </h3>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                Upload a PDF or paste text to generate a summary
              </p>
            </div>
          </div>
        </div>

        {/* Summaries Table */}
        {loading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-rose-500"></div>
          </div>
        ) : summaries.length > 0 ? (
          <div className="overflow-x-auto shadow-md rounded-lg">
            <table className="min-w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
              <thead>
                <tr className="bg-gray-50 dark:bg-gray-700">
                  <th 
                    className="px-4 py-3 border-b border-gray-200 dark:border-gray-600 text-left font-medium text-gray-700 dark:text-gray-200 cursor-pointer"
                    onClick={() => handleSort('originalFileName')}
                  >
                    Name
                    {sortField === 'originalFileName' && (
                      <span className="ml-1">{sortDirection === 'asc' ? '↑' : '↓'}</span>
                    )}
                  </th>
                  <th className="px-4 py-3 border-b border-gray-200 dark:border-gray-600 text-left font-medium text-gray-700 dark:text-gray-200">
                    Summary Preview
                  </th>
                  <th 
                    className="px-4 py-3 border-b border-gray-200 dark:border-gray-600 text-left font-medium text-gray-700 dark:text-gray-200 cursor-pointer"
                    onClick={() => handleSort('createdAt')}
                  >
                    Created At
                    {sortField === 'createdAt' && (
                      <span className="ml-1">{sortDirection === 'asc' ? '↑' : '↓'}</span>
                    )}
                  </th>
                  <th className="px-4 py-3 border-b border-gray-200 dark:border-gray-600 text-left font-medium text-gray-700 dark:text-gray-200">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody>
                {sortedSummaries.map((summary) => (
                  <tr key={summary._id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                    <td className="px-4 py-3 border-b border-gray-200 dark:border-gray-600">
                      {summary.originalFileName}
                    </td>
                    <td className="px-4 py-3 border-b border-gray-200 dark:border-gray-600">
                      {summary.summary && summary.summary.length > 100
                       ? `${summary.summary.slice(0, 100)}...`
                       : summary.summary || 'No Summary'}
                    </td>
                    <td className="px-4 py-3 border-b border-gray-200 dark:border-gray-600">
                      {formatDate(summary.createdAt)}
                    </td>
                    <td className="px-4 py-3 border-b border-gray-200 dark:border-gray-600">
                      <button 
                        onClick={() => viewSummary(summary)}
                        className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 font-medium"
                      >
                        View
                      </button>
                      <button 
                        onClick={() => handleDelete(summary._id)}
                        className="ml-4 text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300 font-medium"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center p-6 bg-gray-50 dark:bg-gray-800 rounded-lg">
            <p className="text-gray-500 dark:text-gray-400">
              No summaries yet. Create your first one!
            </p>
          </div>
        )}
      </div>
    </ProtectedRoute>
  );
}
