'use client'; // Mark this as a Client Component

export default function Providers({ children }) {
  return children;
}
